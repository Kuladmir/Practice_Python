'''
f=open("name.txt")
names=f.readlines()
f.close()
f=open("vote.txt")
votes=f.readlines()
f.close()
f.close()
f=open("vote1.txt","w")
D={}
NUM=0
for vote in _______(1)________:
    num = len(vote.split())
    if num==1 and vote in _______(2)________:
        D[vote[:-1]]=_______(3)________+1
        NUM+=1
    else:
        f.write(_______(4)________)
f.close()
l=list(D.items())
l.sort(key=lambda s:s[1],_______(5)________)
name=____(6)____
score=____(7)____
print("有效票数为：{} 当选村长村民为:{},票数为：{}".format(NUM,name,score))
'''
f=open("name.txt")
names=f.readlines()
f.close()
f=open("vote.txt")
votes=f.readlines()
f.close()
f.close()
f=open("vote1.txt","w")
D={}
NUM=0
for vote in votes: ##先遍历投票表
    num = len(vote.split())
    if num==1 and vote in names:  ## 分析vote里是否只有一个值，且是否在选民表中，以判断是否有效
        D[vote[:-1]]=D.get(vote[:-1],0)+1  ##使用D.get(search,[default])函数查找这个键是否有对应值，否则默认为0
        NUM+=1
    else:
        f.write(vote) ##将无效票内容写入vote.txt
f.close()
l=list(D.items()) ## 将字典赋值给一个列表
l.sort(key=lambda s:s[1],reverse=True)## 对列表的内容进行排序，由大到小
name=l[0][0]
score=l[0][1]
print("有效票数为：{} 当选村长村民为:{},票数为：{}".format(NUM,name,score))