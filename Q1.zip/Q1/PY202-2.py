''' ## 原题：只能替换___处
f = open("vote.txt")
names = f.readlines()
f.close()
D = {}
for name in _______(1)_________:
    if len(_____(2)______)==1:
        D[name[:-1]]=_______(3)_________ + 1
l = list(D.items())
l.sort(key=lambda s:s[1],_______(4)_________)
name = l[0][0]
score = l[0][1]
print("最具人气明星为:{},票数为：{}".format(name,score))
'''
## 解答：
f = open("vote.txt")
names = f.readlines()
f.close()
D = {}
for name in names: ##遍历names列表
    if len(name.split()) == 1: ##判断name里是否只有一个内容
        D[name[:-1]] = D.get(name[:-1],0) + 1 ##通过键=值形式赋值，D.get(search,default)可以找search对应的内容，如果没有则返回default
l = list(D.items()) ## 将字典转化为一个列表
l.sort(key=lambda s:s[1], reverse=True) ## 重要，用于排序
name = l[0][0]
score = l[0][1]
print("最具人气明星为:{},票数为：{}".format(name,score))