''' ## 原题：只能替换___处
f = open("vote.txt")
names = f.readlines()
f.close()
n = 0
for name in _______(1)_________:
    num = _______(2)_________
    if _______(3)________:
        n+=__(4)____
print("有效票{}张".format(n))
'''
## 解答：
f = open('vote.txt')
names = f.readlines() ## 此时，names为一个列表，记录了vote.txt每行的内容，并为一个元素
n = 0
f.close()
for name in names: ## 遍历
    num = len(name.split())  ## 由于元素里可能有两个名字，需要逐个拆开，统计是否是两个内容
    if num == 1: ## 如果只有一个内容，认为是有效
        n += 1
print("有效票{}张".format(n))