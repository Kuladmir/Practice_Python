'''
____________
ls = [69, 292, 33, 131, 61, 254]
X_len = 400
Y_len = 300
x0 = -200
y0 = -100

t.penup()
t.goto(x0, y0)
t.pendown()

t.fd(X_len)
t.fd(-X_len)
t.seth(____________)
t.fd(Y_len)

t.pencolor('red')
t.pensize(5)
for i in range(len(ls)):
    t.____________
    t.goto(x0 + (i+1)*50, ____________)
    t.seth(90)
    t.pendown()
    t.fd(____________)
t.done()
'''

import turtle as t ## 导入turtle库
ls = [69, 292, 33, 131, 61, 254]
X_len = 400
Y_len = 300
x0 = -200
y0 = -100

t.penup()
t.goto(x0, y0)
t.pendown()

t.fd(X_len)
t.fd(-X_len)
t.seth(90) ##设置箭头角度为向上90°，默认为向右，+90表示向左转90
t.fd(Y_len)

t.pencolor('red')
t.pensize(5)
for i in range(len(ls)):
    t.penup() ## 抬起笔尖，不留笔迹，配合pendown
    t.goto(x0 + (i+1)*50, y0) ## 定义了每个柱的其实位置
    t.seth(90)
    t.pendown()
    t.fd(ls[i]) ##根据数值进行长度绘制
t.done()