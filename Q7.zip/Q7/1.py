'''
import random
random.seed(2)

pdict= {'Alice':['123456789'],
        'Bob':['234567891'],
        'Lily':['345678912'],
        'Jane':['456789123']}

name = input('请输入一个人名:')
......
'''
import random
random.seed(2)
pdict= {'Alice':['123456789'],
        'Bob':['234567891'],
        'Lily':['345678912'],
        'Jane':['456789123']}
name = input('请输入一个人名:')
list_1 = list(pdict.items()) ##将字典内容放入有序序列，便于访问
list_2 = list(pdict.keys()) ##将字典中的键值放入序列，便于遍历
for i in range(len(list_1)): ##进行遍历
    if name == list_1[i][0]: ##如果匹配到名字
        randnum = random.randint(1000,9999) ## 在[1000,9999]中产生一个四位随机数
        print(list_1[i][0],list_1[i][1][-1], randnum) ## list_1[i][1]是个列表，如果想得到其中的值，用[-1]
        break
if name not in list_2:
    print("对不起，您输入的用户信息不存在")


