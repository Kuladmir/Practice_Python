'''
names=input("请输入各个同学行业名称，行业名称之间用空格间隔（回车结束输入）：")
...
d = {}
...
ls = list(d.items())
ls.sort(key=lambda x:x[1], reverse=True) # 按照数量排序
for k in ls:
    print("{}:{}".format(______))
'''
names = input()
set_1 = set(names.split()) ## 统计共有什么专业，用集合获取
list_0 = list(set_1)  ##将去除冗余的专业名，转化为列表
print(list_0)
list_1 = names.split() ## 将内容转化为列表，以统计输入内容
print(list_1)
list_num = [] ##建立空列表，用以统计专业数量
d = {}
for name in list_0:
    count =0
    for name_0 in list_1:
        if name == name_0:
            count += 1
    list_num.append(count)
d = dict(zip(list_0, list_num)) ## 获得统计好的字典
ls = list(d.items())
ls.sort(key=lambda x:x[1], reverse=True) # 按照数量排序
for k in ls:
    print("{}:{}".format(k[0],k[1]))