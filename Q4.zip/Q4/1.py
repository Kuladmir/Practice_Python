'''
data = input()  # 姓名 年龄 性别
...
while data:
    ...
    data = input()
...
print("平均年龄是{:.2f} 男性人数是{}".format(______))
'''
data = input()
age = 0
times = 0
male_num = 0
while data:
    l = data.split(" ")
    data = input()
    times += 1
    age += int(l[2])
    if l[1] == '男':
        male_num += 1
print("平均年龄是{:.2f} 男性人数是{}".format(age/times, male_num))