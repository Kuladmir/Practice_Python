'''
data = input()  # 课程名 考分
...
while data:
    ...
    data = input()
...
print("最高分课程是{} {}, 最低分课程是{} {}, 平均分是{:.2f}".format(______))
'''
data = input()
D = {} ## 创建字典去接受键和值
while data:
    l = data.split(" ") ## 将输入：科目 分数，以空格为标识分开，得到列表
    D[l[0]] = int(l[1])  ## 对字典进行赋值
    data = input()
ll = list(D.items()) ##将字典内容赋值给有序列表，用以排序
ll.sort(key=lambda s:s[1],reverse=True) ## 排序
len = len(ll)
average = sum(D.values())/len
print("最高分课程是{} {}, 最低分课程是{} {}, 平均分是{:.2f}".format(ll[0][0],ll[0][1],ll[len-1][0],ll[len-1][1],average))